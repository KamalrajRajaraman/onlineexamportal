import React, { useEffect, useState } from "react";
import MainContent from "./MainContent";
import AccordinMaker from "./AccordinMaker";
import { Outlet, useNavigate } from "react-router-dom";

const Exam = () => {
  const [exams, setExams] = useState([
    {
      id: "1",
      name: "Java",
    },
    {
      id: "2",
      name: "Css",
    },
  ]);
  return (
    <>
      <MainContent text={"Exam"} to="add-exam" back="/admin/exam" />
      <AccordinMaker objects={exams} />
    </>
  );
};

export default Exam;
