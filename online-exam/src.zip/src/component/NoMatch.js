import React from 'react'

const NoMatch = () => {
  return (
    <div>Page Not Found</div>
  )
}

export default NoMatch