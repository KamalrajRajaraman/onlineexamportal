import React from "react";

const AddQuestions = () => {
  return <div className="container-fluid">
    <div>
    <div></div>
    <div></div>
    </div>
  </div>;
};

export default AddQuestions;
