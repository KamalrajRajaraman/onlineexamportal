import React from "react";
import Accordin from "./Accordin";

const AccordinMaker = ({ objects }) => {
  return (
    <div className="mt-2">
      {objects.map((object) => (
        <Accordin key={object.id} object={object} />
      ))}
    </div>
  );
};

export default AccordinMaker;
